package Ecommerce;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ecommerTest {
	
	public void ecommercePage() {
		
		System.setProperty("webdriver.chrome.exe", "/AutomationPrj/src/test/resources/Build/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("softwaretestingboard.com");
		
		WebElement searchTextBox = driver.findElement(By.xpath("//input[contains(@id,'search')]"));
		searchTextBox.sendKeys("Bag");
		
		WebElement searchIcon = driver.findElement(By.xpath("(//button[contains(@type,'submit')])[1]"));
		searchIcon.click();
		
		WebElement productItem = driver.findElement(By.xpath("(//img[contains(@class,'product-image-photo')])[1]"));
		
		Actions action = new Actions(driver);
		action.moveToElement(productItem).build().perform();
		
		WebElement addToCartBtn = driver.findElement(By.xpath("(//button[contains(@type,'submit')]/span[contains(text(),'Add to Cart')])[1]"));
		addToCartBtn.click();
		
		WebElement myCartBtn = driver.findElement(By.xpath("//a[contains(@class,'action showcart active')]//span[contains(@class,'counter qty')]"));
		myCartBtn.click();
		driver.navigate().refresh();
		
		
		if(productItem.isDisplayed()) {
			System.out.println("Product is added to the shopping cart");
		}
		else {
			System.out.println("Product is not added to the shopping cart");
		}
	}

}
